import React, { useState } from 'react';
import Navbar from './Navbar';
import Hero from './Hero';
import CategoryGrid from './CategoryGrid';
import TrustBanner from './TrustBanner';
import ProjectsSection from './ProjectsSection';
import ServicesSection from './ServicesSection';
import FeaturedProviders from './FeaturedProviders';
import HowItWorks from './HowItWorks';
import CTASection from './CTASection';
import Footer from './Footer';

const AppLayout: React.FC = () => {
  const [mode, setMode] = useState<'projects' | 'services'>('projects');

  const handleModeChange = (newMode: 'projects' | 'services') => {
    setMode(newMode);
  };

  const handleCategoryClick = (categoryId: string) => {
    console.log('Category clicked:', categoryId);
  };

  const handleProjectClick = (projectId: string) => {
    console.log('Project clicked:', projectId);
  };

  const handleServiceClick = (serviceId: string) => {
    console.log('Service clicked:', serviceId);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar mode={mode} onModeChange={handleModeChange} />
      
      <Hero onModeChange={handleModeChange} currentMode={mode} />
      
      <TrustBanner />
      
      <CategoryGrid mode={mode} onCategoryClick={handleCategoryClick} />
      
      {mode === 'projects' ? (
        <ProjectsSection onProjectClick={handleProjectClick} />
      ) : (
        <ServicesSection onServiceClick={handleServiceClick} />
      )}
      
      <FeaturedProviders />
      
      <HowItWorks mode={mode} />
      
      <CTASection mode={mode} />
      
      <Footer />
    </div>
  );
};

export default AppLayout;
