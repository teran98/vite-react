import React from 'react';
import ReviewStars from './ReviewStars';

const FeaturedProviders: React.FC = () => {
  const providers = [
    {
      name: 'Sarah Johnson',
      image: 'https://d64gsuwffb70l.cloudfront.net/68e18f136cf6a3bcfa874eee_1759612758070_8ead036e.webp',
      title: 'Marketing Strategist',
      rating: 5.0,
      reviews: 89,
      hourlyRate: 65
    },
    {
      name: 'David Martinez',
      image: 'https://d64gsuwffb70l.cloudfront.net/68e18f136cf6a3bcfa874eee_1759612759816_9f3bfbed.webp',
      title: 'Professional Photographer',
      rating: 4.9,
      reviews: 142,
      hourlyRate: 85
    },
    {
      name: 'Emily Roberts',
      image: 'https://d64gsuwffb70l.cloudfront.net/68e18f136cf6a3bcfa874eee_1759612763940_03ef3d42.webp',
      title: 'Graphic Designer',
      rating: 5.0,
      reviews: 167,
      hourlyRate: 55
    },
    {
      name: 'Michael Brown',
      image: 'https://d64gsuwffb70l.cloudfront.net/68e18f136cf6a3bcfa874eee_1759612764782_bd3d710a.webp',
      title: 'Landscaping Expert',
      rating: 4.8,
      reviews: 93,
      hourlyRate: 45
    }
  ];

  return (
    <div className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-3">Featured Providers</h2>
          <p className="text-lg text-gray-600">Top-rated professionals ready to help</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {providers.map((provider, idx) => (
            <div
              key={idx}
              className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer border border-gray-100 hover:border-blue-300"
            >
              <img
                src={provider.image}
                alt={provider.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-5">
                <h3 className="text-lg font-bold text-gray-900 mb-1">{provider.name}</h3>
                <p className="text-sm text-gray-600 mb-3">{provider.title}</p>
                <ReviewStars rating={provider.rating} count={provider.reviews} size="sm" />
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">Hourly Rate</span>
                    <span className="text-lg font-bold text-gray-900">${provider.hourlyRate}/hr</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FeaturedProviders;
