import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface Props {
  recurrence: { type: string; count?: number };
  onChange: (r: any) => void;
}

export default function RecurrencePicker({ recurrence, onChange }: Props) {
  return (
    <div className="space-y-3">
      <Label>Recurrence</Label>
      <Select value={recurrence.type} onValueChange={(v) => onChange({ ...recurrence, type: v })}>
        <SelectTrigger><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="none">None</SelectItem>
          <SelectItem value="weekly">Weekly</SelectItem>
          <SelectItem value="biweekly">Bi-weekly</SelectItem>
          <SelectItem value="monthly">Monthly</SelectItem>
        </SelectContent>
      </Select>
      {recurrence.type !== 'none' && (
        <>
          <Label>Number of Occurrences</Label>
          <Input
            type="number"
            min={2}
            max={52}
            value={recurrence.count || 4}
            onChange={(e) => onChange({ ...recurrence, count: parseInt(e.target.value) })}
          />
        </>
      )}
    </div>
  );
}
