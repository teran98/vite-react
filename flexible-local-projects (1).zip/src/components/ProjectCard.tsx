import React from 'react';
import CategoryIcon from './CategoryIcon';

interface ProjectCardProps {
  project: {
    id: string;
    title: string;
    category: string;
    budget: string;
    type: string;
    mode: string;
    island: string;
    description: string;
    skills: string[];
    posted: string;
    proposals: number;
  };
  onClick: () => void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, onClick }) => {
  const getModeColor = (mode: string) => {
    const colors: Record<string, string> = {
      Remote: 'bg-blue-100 text-blue-800',
      'On-site': 'bg-green-100 text-green-800',
      Hybrid: 'bg-purple-100 text-purple-800'
    };
    return colors[mode] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 p-6 cursor-pointer border border-gray-100 hover:border-blue-300"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <CategoryIcon icon="code" color="#4D96FF" size="sm" />
          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getModeColor(project.mode)}`}>
            {project.mode}
          </span>
        </div>
        <span className="text-xs text-gray-500">{project.posted}</span>
      </div>
      
      <h3 className="text-lg font-bold text-gray-900 mb-2 hover:text-blue-600 transition-colors">
        {project.title}
      </h3>
      
      <p className="text-sm text-gray-600 mb-4 line-clamp-2">
        {project.description}
      </p>
      
      <div className="flex flex-wrap gap-2 mb-4">
        {project.skills.slice(0, 3).map((skill, idx) => (
          <span key={idx} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
            {skill}
          </span>
        ))}
      </div>
      
      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
        <div>
          <p className="text-xs text-gray-500 mb-1">{project.type} Price</p>
          <p className="text-lg font-bold text-gray-900">{project.budget}</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-gray-500 mb-1">📍 {project.island}</p>
          <p className="text-sm font-semibold text-blue-600">{project.proposals} proposals</p>
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;
