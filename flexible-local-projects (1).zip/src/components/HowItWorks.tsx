import React from 'react';

interface HowItWorksProps {
  mode: 'projects' | 'services';
}

const HowItWorks: React.FC<HowItWorksProps> = ({ mode }) => {
  const projectSteps = [
    { icon: '📝', title: 'Post Your Project', description: 'Describe your project needs and budget' },
    { icon: '👥', title: 'Receive Proposals', description: 'Get bids from qualified freelancers' },
    { icon: '✅', title: 'Hire & Collaborate', description: 'Choose the best fit and work together' },
    { icon: '💰', title: 'Pay Securely', description: 'Release payment when satisfied' }
  ];

  const serviceSteps = [
    { icon: '🔍', title: 'Browse Services', description: 'Find the perfect service provider' },
    { icon: '📅', title: 'Book Instantly', description: 'Choose a package and schedule' },
    { icon: '🤝', title: 'Get Service', description: 'Provider comes to you or you visit them' },
    { icon: '⭐', title: 'Leave Review', description: 'Rate your experience' }
  ];

  const steps = mode === 'projects' ? projectSteps : serviceSteps;

  return (
    <div className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-3">How It Works</h2>
          <p className="text-lg text-gray-600">
            {mode === 'projects' ? 'Get your project done in 4 simple steps' : 'Book services in minutes'}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, idx) => (
            <div key={idx} className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full flex items-center justify-center text-4xl mx-auto mb-4 shadow-lg">
                {step.icon}
              </div>
              <div className="text-sm font-bold text-blue-600 mb-2">STEP {idx + 1}</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HowItWorks;
