import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-2xl font-black mb-4 bg-gradient-to-r from-yellow-300 to-orange-400 bg-clip-text text-transparent">
              BahamaWorks
            </h3>
            <p className="text-gray-300 text-sm mb-4">
              Connecting Bahamian talent with opportunities across the islands.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors">
                <span className="text-sm">f</span>
              </a>
              <a href="#" className="w-8 h-8 bg-blue-400 rounded-full flex items-center justify-center hover:bg-blue-500 transition-colors">
                <span className="text-sm">𝕏</span>
              </a>
              <a href="#" className="w-8 h-8 bg-pink-600 rounded-full flex items-center justify-center hover:bg-pink-700 transition-colors">
                <span className="text-sm">in</span>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">For Clients</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Post a Project</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Browse Talent</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Book Services</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">How It Works</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">For Freelancers</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Find Projects</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Create Service Listing</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Success Stories</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Resources</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Company</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="#" className="hover:text-yellow-400 transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Contact</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Privacy Policy</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8">
          <div className="flex justify-center gap-6 mb-4 text-sm">
            <a href="/" className="text-gray-400 hover:text-yellow-400">Home</a>
            <a href="/#projects" className="text-gray-400 hover:text-yellow-400">Projects</a>
            <a href="/#services" className="text-gray-400 hover:text-yellow-400">Services</a>
            <a href="/admin" className="text-gray-400 hover:text-yellow-400">Admin</a>
          </div>
          <p className="text-center text-sm text-gray-400">&copy; 2025 BahamaWorks. Proudly Bahamian. All rights reserved.</p>
        </div>

      </div>
    </footer>
  );
};

export default Footer;
