import React from 'react';
import ReviewStars from './ReviewStars';

interface ServiceCardProps {
  service: any;
  onClick: () => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer border border-gray-100 hover:border-blue-300"
    >
      <div className="relative">
        <div className="w-full h-48 bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-4xl font-bold">
          {service.title[0]}
        </div>
        {service.instantBook && (
          <div className="absolute top-3 right-3 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-bold">
            ⚡ Instant Book
          </div>
        )}
      </div>
      
      <div className="p-5">
        <h3 className="text-lg font-bold text-gray-900 mb-2">{service.title}</h3>
        <p className="text-sm text-gray-600 mb-3">{service.pitch}</p>
        
        <ReviewStars rating={service.ratingAvg} count={service.ratingCount} size="sm" />
        
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="flex items-center justify-between text-xs text-gray-600 mb-2">
            <span>⏱️ {service.minLeadHours}h lead</span>
            <span>📍 {service.islands[0]}</span>
          </div>
          
          <div className="flex items-center justify-between mt-3">
            <div>
              <p className="text-xs text-gray-500">Starting at</p>
              <p className="text-xl font-bold text-gray-900">${service.packages[0].price}</p>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onClick();
              }}
              className="px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg font-semibold text-sm hover:from-blue-700 hover:to-blue-800 transition-all"
            >
              View
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;
