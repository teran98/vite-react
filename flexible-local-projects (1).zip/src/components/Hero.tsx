import React, { useState } from 'react';

interface HeroProps {
  onModeChange: (mode: 'projects' | 'services') => void;
  currentMode: 'projects' | 'services';
}

const Hero: React.FC<HeroProps> = ({ onModeChange, currentMode }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Searching for:', searchQuery);
  };

  return (
    <div className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-teal-700 text-white overflow-hidden">
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: 'url(https://d64gsuwffb70l.cloudfront.net/68e18f136cf6a3bcfa874eee_1759612765602_34d369ee.webp)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-8">
          <h1 className="text-5xl md:text-6xl font-black mb-4 bg-gradient-to-r from-yellow-300 to-orange-400 bg-clip-text text-transparent">
            BahamaWorks
          </h1>
          <p className="text-xl md:text-2xl font-light mb-8">
            Where Island Talent Meets Opportunity
          </p>
        </div>

        <div className="flex justify-center gap-4 mb-8">
          <button
            onClick={() => onModeChange('projects')}
            className={`px-8 py-3 rounded-lg font-bold text-lg transition-all ${
              currentMode === 'projects'
                ? 'bg-white text-blue-900 shadow-lg scale-105'
                : 'bg-blue-800 bg-opacity-50 hover:bg-opacity-70'
            }`}
          >
            🎯 Find Projects
          </button>
          <button
            onClick={() => onModeChange('services')}
            className={`px-8 py-3 rounded-lg font-bold text-lg transition-all ${
              currentMode === 'services'
                ? 'bg-white text-blue-900 shadow-lg scale-105'
                : 'bg-blue-800 bg-opacity-50 hover:bg-opacity-70'
            }`}
          >
            ⚡ Find Services
          </button>
        </div>

        <form onSubmit={handleSearch} className="max-w-3xl mx-auto">
          <div className="flex gap-2">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                currentMode === 'projects'
                  ? 'Search for projects, skills, or categories...'
                  : 'Search for services, providers, or locations...'
              }
              className="flex-1 px-6 py-4 rounded-lg text-gray-900 text-lg focus:outline-none focus:ring-4 focus:ring-yellow-400"
            />
            <button
              type="submit"
              className="px-8 py-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-gray-900 rounded-lg font-bold text-lg hover:from-yellow-500 hover:to-orange-600 transition-all shadow-lg"
            >
              Search
            </button>
          </div>
        </form>

        <div className="flex justify-center gap-6 mt-8">
          <button className="px-6 py-3 bg-gradient-to-r from-green-500 to-teal-500 rounded-lg font-bold hover:from-green-600 hover:to-teal-600 transition-all shadow-lg">
            {currentMode === 'projects' ? '📝 Post a Project' : '🎯 Create Service Listing'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;
