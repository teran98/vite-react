import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import PackageSelector from './PackageSelector';
import RecurrencePicker from './RecurrencePicker';

interface Props {
  open: boolean;
  onClose: () => void;
  service: any;
  instantBook: boolean;
}

export default function BookingModal({ open, onClose, service, instantBook }: Props) {
  const [pkg, setPkg] = useState(0);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [recurrence, setRecurrence] = useState({ type: 'none', count: 4 });
  const [notes, setNotes] = useState('');

  const handleSubmit = () => {
    const booking = {
      serviceId: service.id,
      package: service.packages[pkg],
      date, time, recurrence, notes,
      status: instantBook ? 'Confirmed' : 'Pending',
      total: service.packages[pkg].price
    };
    console.log('Booking:', booking);
    alert(instantBook ? 'Booking confirmed!' : 'Quote request sent!');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{instantBook ? 'Instant Book' : 'Request Quote'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <PackageSelector packages={service.packages} selected={pkg} onSelect={setPkg} />
          <div className="grid md:grid-cols-2 gap-4">
            <div><Label>Date</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
            <div><Label>Time</Label><Input type="time" value={time} onChange={(e) => setTime(e.target.value)} /></div>
          </div>
          {instantBook && <RecurrencePicker recurrence={recurrence} onChange={setRecurrence} />}
          <div><Label>Notes</Label><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} /></div>
          <div className="bg-blue-50 p-4 rounded">
            <p className="text-sm text-gray-600">Total: <span className="text-2xl font-bold">${service.packages[pkg].price}</span></p>
            {recurrence.type !== 'none' && <p className="text-xs mt-1">Per visit • {recurrence.count} occurrences</p>}
          </div>
          <Button onClick={handleSubmit} className="w-full">{instantBook ? 'Confirm Booking' : 'Send Quote Request'}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
