import React, { useState } from 'react';

interface NavbarProps {
  mode: 'projects' | 'services';
  onModeChange: (mode: 'projects' | 'services') => void;
}

const Navbar: React.FC<NavbarProps> = ({ mode, onModeChange }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-8">
            <a href="/" className="text-2xl font-black bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent">
              BahamaWorks
            </a>
            
            <div className="hidden md:flex gap-2">
              <button
                onClick={() => onModeChange('projects')}
                className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
                  mode === 'projects'
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                Projects
              </button>
              <button
                onClick={() => onModeChange('services')}
                className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
                  mode === 'services'
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                Services
              </button>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-4">
            <button className="px-4 py-2 text-gray-700 font-semibold hover:text-blue-600 transition-colors">
              Sign In
            </button>
            <button className="px-6 py-2 bg-gradient-to-r from-blue-600 to-teal-600 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-teal-700 transition-all shadow-md">
              {mode === 'projects' ? 'Post Project' : 'Create Listing'}
            </button>
          </div>
          
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
        
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <div className="flex flex-col gap-2">
              <button
                onClick={() => {
                  onModeChange('projects');
                  setIsMenuOpen(false);
                }}
                className="px-4 py-2 text-left text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Projects
              </button>
              <button
                onClick={() => {
                  onModeChange('services');
                  setIsMenuOpen(false);
                }}
                className="px-4 py-2 text-left text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Services
              </button>
              <button className="px-4 py-2 text-left text-gray-700 hover:bg-gray-100 rounded-lg">
                Sign In
              </button>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold">
                {mode === 'projects' ? 'Post Project' : 'Create Listing'}
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
