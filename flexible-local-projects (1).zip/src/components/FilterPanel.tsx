import React from 'react';

interface FilterPanelProps {
  mode: 'projects' | 'services';
  onFilterChange: (filters: any) => void;
}

const FilterPanel: React.FC<FilterPanelProps> = ({ mode, onFilterChange }) => {
  const islands = ['Nassau', 'Paradise Island', 'Freeport', 'Exuma', 'Eleuthera', 'Abaco'];
  
  return (
    <div className="bg-white rounded-xl shadow-md p-6 sticky top-4">
      <h3 className="text-lg font-bold text-gray-900 mb-4">Filters</h3>
      
      {mode === 'projects' ? (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Budget Range</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
              <option>Any Budget</option>
              <option>Under $500</option>
              <option>$500 - $1,000</option>
              <option>$1,000 - $5,000</option>
              <option>$5,000+</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Work Mode</label>
            <div className="space-y-2">
              {['Remote', 'On-site', 'Hybrid'].map((mode) => (
                <label key={mode} className="flex items-center">
                  <input type="checkbox" className="mr-2 rounded" />
                  <span className="text-sm text-gray-700">{mode}</span>
                </label>
              ))}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Island</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
              <option>All Islands</option>
              {islands.map((island) => (
                <option key={island}>{island}</option>
              ))}
            </select>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Price Range</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
              <option>Any Price</option>
              <option>Under $50</option>
              <option>$50 - $100</option>
              <option>$100 - $200</option>
              <option>$200+</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Island</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
              <option>All Islands</option>
              {islands.map((island) => (
                <option key={island}>{island}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Rating</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
              <option>Any Rating</option>
              <option>4.5+ ⭐</option>
              <option>4.0+ ⭐</option>
              <option>3.5+ ⭐</option>
            </select>
          </div>
          
          <div>
            <label className="flex items-center">
              <input type="checkbox" className="mr-2 rounded" />
              <span className="text-sm font-semibold text-gray-700">Instant Book Only</span>
            </label>
          </div>
          
          <div>
            <label className="flex items-center">
              <input type="checkbox" className="mr-2 rounded" />
              <span className="text-sm font-semibold text-gray-700">Verified Only</span>
            </label>
          </div>
        </div>
      )}
      
      <button className="w-full mt-6 px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors">
        Apply Filters
      </button>
    </div>
  );
};

export default FilterPanel;
