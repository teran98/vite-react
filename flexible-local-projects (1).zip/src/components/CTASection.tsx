import React from 'react';

interface CTASectionProps {
  mode: 'projects' | 'services';
}

const CTASection: React.FC<CTASectionProps> = ({ mode }) => {
  return (
    <div className="bg-gradient-to-br from-blue-900 via-teal-800 to-blue-900 py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
          {mode === 'projects' 
            ? 'Ready to Find the Perfect Freelancer?' 
            : 'Need a Service Today?'}
        </h2>
        <p className="text-xl text-blue-100 mb-8">
          {mode === 'projects'
            ? 'Post your project now and receive proposals from talented Bahamian professionals'
            : 'Browse hundreds of verified service providers ready to help you'}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="px-8 py-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-gray-900 rounded-lg font-bold text-lg hover:from-yellow-500 hover:to-orange-600 transition-all shadow-lg">
            {mode === 'projects' ? '📝 Post a Project' : '🎯 Browse Services'}
          </button>
          <button className="px-8 py-4 bg-white text-blue-900 rounded-lg font-bold text-lg hover:bg-gray-100 transition-all shadow-lg">
            Learn More
          </button>
        </div>
        <p className="text-sm text-blue-200 mt-6">
          ✓ No fees to post  ✓ Secure payments  ✓ 24/7 support
        </p>
      </div>
    </div>
  );
};

export default CTASection;
