import React from 'react';

const TrustBanner: React.FC = () => {
  const stats = [
    { value: '5,000+', label: 'Active Freelancers', icon: '👥' },
    { value: '12,000+', label: 'Projects Completed', icon: '✅' },
    { value: '4.8/5', label: 'Average Rating', icon: '⭐' },
    { value: '$2.5M+', label: 'Paid to Freelancers', icon: '💰' }
  ];

  return (
    <div className="bg-gradient-to-r from-blue-600 via-teal-600 to-blue-600 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, idx) => (
            <div key={idx} className="text-center">
              <div className="text-4xl mb-2">{stat.icon}</div>
              <div className="text-3xl font-black text-white mb-1">{stat.value}</div>
              <div className="text-sm text-blue-100 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TrustBanner;
