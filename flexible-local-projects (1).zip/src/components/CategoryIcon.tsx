import React from 'react';

interface CategoryIconProps {
  icon: string;
  color?: string;
  size?: 'sm' | 'md' | 'lg';
}

const CategoryIcon: React.FC<CategoryIconProps> = ({ icon, color = '#4D96FF', size = 'md' }) => {
  const sizeClasses = {
    sm: 'w-5 h-5',
    md: 'w-6 h-6',
    lg: 'w-8 h-8'
  };

  const iconMap: Record<string, string> = {
    palette: 'M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01',
    gem: 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z',
    camera: 'M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z M15 12a3 3 0 11-6 0 3 3 0 016 0z',
    megaphone: 'M11 5L6 9H2v6h4l5 4V5z M19.07 4.93a10 10 0 010 14.14 M15.54 8.46a5 5 0 010 7.07',
    code: 'M16 18l6-6-6-6 M8 6l-6 6 6 6',
    car: 'M5 17h14v2H5v-2zm-1-5h16l-2-6H6l-2 6zm2 0a1 1 0 100 2 1 1 0 000-2zm12 0a1 1 0 100 2 1 1 0 000-2z',
    baby: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3z',
    book: 'M4 19.5A2.5 2.5 0 016.5 17H20 M4 19.5A2.5 2.5 0 016.5 22H20V2H6.5A2.5 2.5 0 004 4.5v15z',
    tool: 'M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z',
    sparkles: 'M5 3v4M3 5h4 M6 17v4 M4 19h4 M12 2l1 5 5 1-5 1-1 5-1-5-5-1 5-1 1-5z M17 8l1 3 3 1-3 1-1 3-1-3-3-1 3-1 1-3z',
    scissors: 'M9 3L5 7l4 4L5 15l4 4 M15 3l4 4-4 4 4 4-4 4 M12 12h.01',
    chef: 'M6 13.87A4 4 0 017.41 6a5.11 5.11 0 011.05-1.54 5 5 0 017.08 0A5.11 5.11 0 0116.59 6 4 4 0 0118 13.87V21H6z M6 17h12',
    tree: 'M12 2L8 8h3v8H8l4 6 4-6h-3V8h3l-4-6z'
  };

  return (
    <svg
      className={sizeClasses[size]}
      fill="none"
      stroke={color}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      viewBox="0 0 24 24"
    >
      <path d={iconMap[icon] || iconMap.palette} />
    </svg>
  );
};

export default CategoryIcon;
