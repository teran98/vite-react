import React from 'react';
import { useNavigate } from 'react-router-dom';
import ServiceCard from './ServiceCard';
import { seedServices } from '../lib/seed/servicesSeed';

interface ServicesSectionProps {
  onServiceClick: (serviceId: string) => void;
}

const ServicesSection: React.FC<ServicesSectionProps> = ({ onServiceClick }) => {
  const navigate = useNavigate();
  
  const handleClick = (id: string) => {
    navigate(`/services/${id}`);
    onServiceClick(id);
  };

  return (
    <div className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Available Services</h2>
            <p className="text-gray-600 mt-1">{seedServices.length} service providers available</p>
          </div>
          
          <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white">
            <option>Top Rated</option>
            <option>Most Booked</option>
            <option>Near Me</option>
          </select>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {seedServices.map((service) => (
            <ServiceCard
              key={service.id}
              service={service}
              onClick={() => handleClick(service.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ServicesSection;
