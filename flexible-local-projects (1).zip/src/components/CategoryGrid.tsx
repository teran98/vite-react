import React, { useEffect, useState } from 'react';
import CategoryIcon from './CategoryIcon';

interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
  subcategories: string[];
}

interface CategoryGridProps {
  mode: 'projects' | 'services';
  onCategoryClick: (categoryId: string) => void;
}

const CategoryGrid: React.FC<CategoryGridProps> = ({ mode, onCategoryClick }) => {
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    fetch('/categories.json')
      .then((res) => res.json())
      .then((data) => {
        setCategories(mode === 'projects' ? data.professional : data.local);
      })
      .catch((err) => console.error('Error loading categories:', err));
  }, [mode]);

  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
          Browse by Category
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => onCategoryClick(category.id)}
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all duration-300 group border-2 border-transparent hover:border-blue-400"
              style={{ borderColor: 'transparent' }}
            >
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center mb-3 mx-auto transition-transform group-hover:scale-110"
                style={{ backgroundColor: `${category.color}20` }}
              >
                <CategoryIcon icon={category.icon} color={category.color} size="md" />
              </div>
              <h3 className="font-bold text-gray-900 text-sm text-center mb-1">
                {category.name}
              </h3>
              <p className="text-xs text-gray-500 text-center">
                {category.subcategories.length} subcategories
              </p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CategoryGrid;
