import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Check } from 'lucide-react';

interface Package {
  name: string;
  desc: string;
  duration: number;
  price: number;
}

interface Props {
  packages: Package[];
  selected: number;
  onSelect: (idx: number) => void;
}

export default function PackageSelector({ packages, selected, onSelect }: Props) {
  return (
    <div className="grid md:grid-cols-3 gap-4">
      {packages.map((pkg, idx) => (
        <Card
          key={idx}
          className={`p-4 cursor-pointer transition ${selected === idx ? 'border-blue-600 border-2 bg-blue-50' : 'hover:border-gray-400'}`}
          onClick={() => onSelect(idx)}
        >
          {selected === idx && <Check className="w-5 h-5 text-blue-600 float-right" />}
          <h3 className="font-bold text-lg">{pkg.name}</h3>
          <p className="text-sm text-gray-600 my-2">{pkg.desc}</p>
          <p className="text-xs text-gray-500">{pkg.duration} min</p>
          <p className="text-2xl font-bold mt-2">${pkg.price}</p>
        </Card>
      ))}
    </div>
  );
}
