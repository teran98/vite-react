export const seedProviders = [
  { id: "u_carwash", email: "sparkle@demo.com", name: "Island Sparkle Detailing", bio: "Premium on-site detailing", location: "Nassau", rating: 4.9 },
  { id: "u_babysit", email: "miss.t@demo.com", name: "Miss T's Babysitting", bio: "CPR/First Aid certified", location: "Nassau", rating: 4.8 },
  { id: "u_tutor", email: "elite@demo.com", name: "Elite Tutoring Nassau", bio: "BJC/BGCSE & SAT", location: "Nassau", rating: 4.9 },
  { id: "u_clean", email: "clean@demo.com", name: "CleanFam Services", bio: "Recurring schedules available", location: "Freeport", rating: 4.7 },
  { id: "u_mechanic", email: "auto@demo.com", name: "Island Auto Mechanics", bio: "Mobile diagnostics & repair", location: "Nassau", rating: 4.9 },
  { id: "u_moving", email: "movers@demo.com", name: "Island Movers", bio: "Reliable truck & crew", location: "Nassau", rating: 4.8 },
  { id: "u_realtor", email: "realty@demo.com", name: "Bahama Realty Pro", bio: "Licensed agents", location: "Nassau", rating: 5.0 }
];

export const seedServices = [
  {
    id: "svc_carwash", ownerId: "u_carwash", categoryId: "car-wash", title: "Island Sparkle Mobile Car Wash",
    pitch: "We come to you — sedan to SUV — spotless inside & out.", type: "On-site", islands: ["Nassau"], radiusKm: 25,
    packages: [
      { name: "Basic Exterior", desc: "Hand wash, dry, wheels", duration: 45, price: 40 },
      { name: "Full Detail", desc: "Exterior + interior vacuum", duration: 90, price: 90 },
      { name: "Premium Ceramic", desc: "Full detail + ceramic coat", duration: 120, price: 150 }
    ],
    addons: [{ name: "Engine Bay", price: 25 }, { name: "Pet Hair Removal", price: 20 }],
    attributes: { vehicleTypes: ["Sedan","SUV","Truck"], serviceScope: "Full Detail", waterPower: true },
    instantBook: true, minLeadHours: 6, cancelWindowHours: 12, ratingAvg: 4.9, ratingCount: 128, status: "active"
  },
  {
    id: "svc_babysit", ownerId: "u_babysit", categoryId: "childcare", title: "Miss T's Babysitting",
    pitch: "CPR/First Aid — patient, fun, responsible care.", type: "On-site", islands: ["Nassau"], radiusKm: 15,
    packages: [
      { name: "Evening (3hrs)", desc: "3-hour evening block", duration: 180, price: 60 },
      { name: "Half-Day", desc: "Up to 5 hours", duration: 300, price: 95 },
      { name: "Full-Day", desc: "8 hours", duration: 480, price: 160 }
    ],
    addons: [{ name: "Homework Help", price: 10 }],
    attributes: { childrenCount: 1, ages: ["3-5","6-9"], firstAid: true, specialNeeds: false },
    instantBook: false, minLeadHours: 12, cancelWindowHours: 24, ratingAvg: 4.8, ratingCount: 82, status: "active"
  },
  {
    id: "svc_tutor", ownerId: "u_tutor", categoryId: "tutoring", title: "Elite Tutoring Nassau",
    pitch: "Math & English — BJC/BGCSE & SAT prep.", type: "Mixed", islands: ["Nassau"], radiusKm: 10,
    packages: [
      { name: "Single Session", desc: "1-hour tutoring", duration: 60, price: 35 },
      { name: "5-Pack", desc: "Save $25", duration: 300, price: 150 },
      { name: "10-Pack", desc: "Save $100", duration: 600, price: 250 }
    ],
    addons: [],
    attributes: { subjects: ["Math","English","SAT/ACT"], level: "Senior High", mode: "Hybrid" },
    instantBook: true, minLeadHours: 12, cancelWindowHours: 24, ratingAvg: 4.9, ratingCount: 64, status: "active"
  },
  {
    id: "svc_clean", ownerId: "u_clean", categoryId: "cleaning", title: "CleanFam Services",
    pitch: "Homes & offices — deep clean options.", type: "On-site", islands: ["Freeport"], radiusKm: 20,
    packages: [
      { name: "Basic Clean", desc: "Standard cleaning", duration: 120, price: 80 },
      { name: "Deep Clean", desc: "Thorough cleaning", duration: 240, price: 160 },
      { name: "Move-Out", desc: "Complete move-out", duration: 360, price: 250 }
    ],
    addons: [{ name: "Carpet Shampoo", price: 40 }],
    attributes: { spaceType: "Home", sqft: "1500-2500", supplies: true, deepClean: true },
    instantBook: true, minLeadHours: 12, cancelWindowHours: 24, ratingAvg: 4.7, ratingCount: 51, status: "active"
  },
  {
    id: "svc_mechanic", ownerId: "u_mechanic", categoryId: "mechanic", title: "Island Auto Mechanics",
    pitch: "Mobile diagnostics, oil change, brake repair.", type: "On-site", islands: ["Nassau"], radiusKm: 20,
    packages: [
      { name: "Diagnostic", desc: "Full vehicle scan", duration: 60, price: 50 },
      { name: "Brake Service", desc: "Pads + fluid", duration: 120, price: 120 },
      { name: "Emergency", desc: "Jump, tire change", duration: 45, price: 75 }
    ],
    addons: [{ name: "Oil Change", price: 40 }],
    attributes: { serviceTypes: ["General Repair","Diagnostics"], certified: true },
    instantBook: true, minLeadHours: 4, cancelWindowHours: 12, ratingAvg: 4.9, ratingCount: 47, status: "active"
  },
  {
    id: "svc_moving", ownerId: "u_moving", categoryId: "moving", title: "Island Movers & Hauling",
    pitch: "Reliable truck & crew for moves & junk removal.", type: "On-site", islands: ["Nassau","Freeport"], radiusKm: 30,
    packages: [
      { name: "Small Move", desc: "Studio/1-bedroom", duration: 180, price: 180 },
      { name: "Standard", desc: "2-3 bedrooms", duration: 300, price: 300 },
      { name: "Large", desc: "4+ bedrooms", duration: 480, price: 450 }
    ],
    addons: [{ name: "Packing Materials", price: 25 }],
    attributes: { moveTypes: ["Residential","Office"], truckSize: "14-ft box" },
    instantBook: false, minLeadHours: 12, cancelWindowHours: 24, ratingAvg: 4.8, ratingCount: 65, status: "active"
  },
  {
    id: "svc_realtor", ownerId: "u_realtor", categoryId: "real-estate", title: "Bahama Realty Pro",
    pitch: "Licensed agents — buy, sell, rent.", type: "Mixed", islands: ["Nassau","Abaco","Exuma"], radiusKm: 50,
    packages: [
      { name: "Property Viewing", desc: "Guided tour", duration: 90, price: 0 },
      { name: "Listing Consult", desc: "Pricing advice", duration: 60, price: 100 },
      { name: "Rental Mgmt", desc: "Monthly oversight", duration: 0, price: 150 }
    ],
    addons: [{ name: "Pro Photos", price: 120 }],
    attributes: { serviceScope: ["Sales","Rentals"], licensed: true },
    instantBook: false, minLeadHours: 24, cancelWindowHours: 48, ratingAvg: 5.0, ratingCount: 33, status: "active"
  }
];
