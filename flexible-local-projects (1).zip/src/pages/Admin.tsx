import React from 'react';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';

export default function Admin() {
  const resetDemo = () => alert('Demo data reset!');
  const approveVerif = () => alert('Verification approved!');
  const viewBookings = () => alert('Showing bookings list...');

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
        <div className="grid md:grid-cols-3 gap-4">
          <Card className="p-6">
            <h2 className="font-bold mb-3">Reset Demo Data</h2>
            <p className="text-sm text-gray-600 mb-4">Reload seed data</p>
            <Button onClick={resetDemo} variant="outline">Reset</Button>
          </Card>
          <Card className="p-6">
            <h2 className="font-bold mb-3">Approve Verification</h2>
            <p className="text-sm text-gray-600 mb-4">Verify providers</p>
            <Button onClick={approveVerif} variant="outline">Approve</Button>
          </Card>
          <Card className="p-6">
            <h2 className="font-bold mb-3">View Bookings</h2>
            <p className="text-sm text-gray-600 mb-4">All bookings list</p>
            <Button onClick={viewBookings} variant="outline">View</Button>
          </Card>
        </div>
        <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded">
          <p className="text-sm"><strong>Note:</strong> Payments are mocked. Connect a provider in production to enable real escrow & payouts.</p>
        </div>
      </div>
    </div>
  );
}
