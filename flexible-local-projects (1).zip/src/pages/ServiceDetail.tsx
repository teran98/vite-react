import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Star, MapPin, Clock, CheckCircle } from 'lucide-react';
import BookingModal from '../components/BookingModal';
import { seedServices, seedProviders } from '../lib/seed/servicesSeed';

export default function ServiceDetail() {
  const { id } = useParams();
  const service = seedServices.find(s => s.id === id);
  const provider = seedProviders.find(p => p.id === service?.ownerId);
  const [bookingOpen, setBookingOpen] = useState(false);

  if (!service || !provider) return <div className="p-8">Service not found</div>;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold mb-2">{service.title}</h1>
              <p className="text-gray-600 mb-4">{service.pitch}</p>
              <div className="flex gap-4 text-sm">
                <span className="flex items-center gap-1"><Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />{service.ratingAvg} ({service.ratingCount})</span>
                <span className="flex items-center gap-1"><MapPin className="w-4 h-4" />{service.islands.join(', ')}</span>
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" />{service.minLeadHours}h lead time</span>
              </div>
            </div>
            <Badge variant={service.instantBook ? 'default' : 'secondary'}>
              {service.instantBook ? 'Instant Book' : 'Request Quote'}
            </Badge>
          </div>

          <div className="mb-6">
            <h2 className="text-xl font-bold mb-3">Provider</h2>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                {provider.name[0]}
              </div>
              <div>
                <p className="font-semibold">{provider.name}</p>
                <p className="text-sm text-gray-600">{provider.bio}</p>
              </div>
            </div>
          </div>

          {service.attributes && (
            <div className="mb-6 p-4 bg-gray-50 rounded">
              <h3 className="font-bold mb-2">Service Details</h3>
              {Object.entries(service.attributes).map(([k, v]) => (
                <p key={k} className="text-sm"><span className="font-medium">{k}:</span> {Array.isArray(v) ? v.join(', ') : String(v)}</p>
              ))}
            </div>
          )}

          <div className="mb-6">
            <h2 className="text-xl font-bold mb-3">Packages</h2>
            <div className="grid md:grid-cols-3 gap-4">
              {service.packages.map((pkg: any, i: number) => (
                <div key={i} className="border rounded p-4">
                  <h3 className="font-bold">{pkg.name}</h3>
                  <p className="text-sm text-gray-600 my-2">{pkg.desc}</p>
                  <p className="text-xs text-gray-500">{pkg.duration} min</p>
                  <p className="text-2xl font-bold mt-2">${pkg.price}</p>
                </div>
              ))}
            </div>
          </div>

          <Button onClick={() => setBookingOpen(true)} size="lg" className="w-full md:w-auto">
            {service.instantBook ? 'Book Now' : 'Request Quote'}
          </Button>
        </div>
      </div>

      <BookingModal open={bookingOpen} onClose={() => setBookingOpen(false)} service={service} instantBook={service.instantBook} />
    </div>
  );
}
