# BahamaWorks Marketplace Hub

A dual-marketplace platform connecting Bahamian professionals with project opportunities and local service bookings.

## Features

### Dual Marketplace
- **Projects**: Post/browse professional gigs (design, dev, marketing, etc.)
- **Services**: Book on-site services with instant-book or request-quote options

### Advanced Booking System
- **Instant Book**: Immediate confirmation for select services
- **Request Quote**: Provider approval workflow for custom jobs
- **Recurring Bookings**: Weekly, bi-weekly, monthly scheduling
- **Package Selection**: Tiered pricing with add-ons

### Category-Specific Smart Forms
Dynamic attribute schemas per category (see `public/categories.json`)

## Demo Mode

### Seed Data Loading
Demo data auto-loads from `src/lib/seed/servicesSeed.ts`:
- 7 providers (car wash, childcare, tutoring, cleaning, mechanic, moving, real estate)
- 7 services with packages, ratings, and attributes
- Sample bookings and reviews

**To disable demo mode**: Comment out seed imports in components.

### Mock Payments
All payment methods in `paymentsService` return mocked responses. Connect real payment gateway in production.

## Category Schemas

Edit `public/categories.json` to customize service attributes:

```json
"attributesSchema": [
  {"key":"vehicleTypes","label":"Vehicle Types","type":"multiselect","options":[...]},
  {"key":"certified","label":"Certified","type":"boolean"}
]
```

**Supported field types**: text, number, select, multiselect, chips, boolean

## Instant Book vs Request Quote

Services have `instantBook` boolean:
- `true`: Booking status = "Confirmed" immediately
- `false`: Booking status = "Pending" until provider approves

Configure per service in seed data or service creation form.

## Development

```bash
npm install
npm run dev
```

## Build & Deploy

```bash
npm run build
npm run preview
```

### Vercel Deployment
1. Connect GitHub repo
2. Framework: Vite
3. Build command: `npm run build`
4. Output: `dist`

SPA routing configured via `vercel.json`.

## Admin Tools

Visit `/admin` for:
- Reset demo data
- Approve verifications
- View bookings list

## Connect Real Payments

Replace mock methods in payment service with:
- Stripe Connect for escrow
- PayPal for instant payouts
- Local Bahamian payment gateways

## Toggle Features

- **Instant Book**: Set `service.instantBook = false` to disable
- **Recurring**: Hide `RecurrencePicker` in `BookingModal`
- **Category Schemas**: Remove `attributesSchema` from categories.json

---

**Built with**: React 18, TypeScript, Vite, Tailwind CSS, shadcn/ui
